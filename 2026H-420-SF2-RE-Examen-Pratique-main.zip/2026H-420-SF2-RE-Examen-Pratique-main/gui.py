import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from models.voiture import Voiture
from models.camion import Camion
from models.collision import Collision
from utils.fichiers import charger_scenarios


class CadreVehicule(ttk.LabelFrame):
    """Cadre de saisie pour les données d'un véhicule."""

    def __init__(self, parent: tk.Widget, titre: str, **kwargs):
        super().__init__(parent, text=titre, **kwargs)
        self._creer_widgets()

    def _creer_widgets(self) -> None:
        # Type
        ttk.Label(self, text="Type :").grid(row=0, column=0, sticky="w", padx=5, pady=3)
        self.var_type = tk.StringVar(value="Voiture")
        self.combo_type = ttk.Combobox(
            self,
            textvariable=self.var_type,
            values=["Voiture", "Camion"],
            state="readonly",
            width=10,
        )
        self.combo_type.grid(row=0, column=1, sticky="ew", padx=5, pady=3)
        self.combo_type.bind("<<ComboboxSelected>>", self._on_type_change)

        # Nom
        ttk.Label(self, text="Nom :").grid(row=1, column=0, sticky="w", padx=5, pady=3)
        self.entry_nom = ttk.Entry(self, width=16)
        self.entry_nom.grid(row=1, column=1, sticky="ew", padx=5, pady=3)

        # Masse
        ttk.Label(self, text="Masse (kg) :").grid(
            row=2, column=0, sticky="w", padx=5, pady=3
        )
        self.entry_masse = ttk.Entry(self, width=10)
        self.entry_masse.grid(row=2, column=1, sticky="ew", padx=5, pady=3)

        # Vitesse
        ttk.Label(self, text="Vitesse (km/h) :").grid(
            row=3, column=0, sticky="w", padx=5, pady=3
        )
        self.entry_vitesse = ttk.Entry(self, width=10)
        self.entry_vitesse.grid(row=3, column=1, sticky="ew", padx=5, pady=3)

        # Champ variable : nb_passagers ou charge_utile
        self.label_extra = ttk.Label(self, text="Nb passagers :")
        self.label_extra.grid(row=4, column=0, sticky="w", padx=5, pady=3)
        self.entry_extra = ttk.Entry(self, width=10)
        self.entry_extra.grid(row=4, column=1, sticky="ew", padx=5, pady=3)
        self.entry_extra.insert(0, "1")

    def _on_type_change(self, _event=None) -> None:
        if self.var_type.get() == "Voiture":
            self.label_extra.config(text="Nb passagers :")
            self.entry_extra.delete(0, tk.END)
            self.entry_extra.insert(0, "1")
        else:
            self.label_extra.config(text="Charge utile (kg) :")
            self.entry_extra.delete(0, tk.END)
            self.entry_extra.insert(0, "0")

    def set_vitesse_activee(self, activee: bool) -> None:
        """Active ou désactive le champ vitesse (utilisé pour les modes inverses)."""
        if activee:
            self.entry_vitesse.config(state="normal")
        else:
            self.entry_vitesse.config(state="normal")
            self.entry_vitesse.delete(0, tk.END)
            self.entry_vitesse.config(state="disabled")

    def get_vehicule(self):
        """
        Construit et retourne un objet Voiture ou Camion à partir des champs.

        Raises:
            ValueError: Si les valeurs saisies sont invalides.
        """
        try:
            nom = self.entry_nom.get().strip() or "Inconnu"
            masse = float(self.entry_masse.get())
            vitesse_str = self.entry_vitesse.get()
            vitesse = float(vitesse_str) if vitesse_str else 0.0

            if self.var_type.get() == "Voiture":
                nb_passagers = int(self.entry_extra.get() or 1)
                return Voiture(nom, masse, vitesse, nb_passagers)
            else:
                charge_utile = float(self.entry_extra.get() or 0)
                return Camion(nom, masse, vitesse, charge_utile)
        except ValueError:
            raise ValueError(
                f"Valeurs invalides dans le cadre « {self.cget('text')} ».\n"
                "Vérifiez que masse, vitesse et le dernier champ sont des nombres valides."
            )

    def get_masse_effective(self) -> float:
        """
        Retourne la masse effective du véhicule saisi.

        Raises:
            ValueError: Si les valeurs numériques sont invalides.
        """
        return self.get_vehicule().masse_effective()

    def remplir(self, data: dict) -> None:
        """Remplit les champs à partir d'un dictionnaire de scénario."""
        self.entry_nom.delete(0, tk.END)
        self.entry_nom.insert(0, str(data.get("nom", "")))

        self.entry_masse.delete(0, tk.END)
        self.entry_masse.insert(0, str(data.get("masse", "")))

        self.entry_vitesse.config(state="normal")
        self.entry_vitesse.delete(0, tk.END)
        vitesse = data.get("vitesse")
        if vitesse is not None:
            self.entry_vitesse.insert(0, str(vitesse))

        type_v = str(data.get("type", "voiture")).lower()
        if type_v == "camion":
            self.var_type.set("Camion")
            self.label_extra.config(text="Charge utile (kg) :")
            self.entry_extra.delete(0, tk.END)
            self.entry_extra.insert(0, str(data.get("charge_utile", 0)))
        else:
            self.var_type.set("Voiture")
            self.label_extra.config(text="Nb passagers :")
            self.entry_extra.delete(0, tk.END)
            self.entry_extra.insert(0, str(data.get("nb_passagers", 1)))


class App(tk.Tk):
    """Fenêtre principale du simulateur de collision."""

    MODES = {
        "simulation": "Simulation  (trouver v_f et θ)",
        "trouver_vb": "Trouver la vitesse de B",
        "trouver_va": "Trouver la vitesse de A",
    }

    def __init__(self):
        super().__init__()
        self.title("Simulateur de collision inélastique à 90°")
        self.resizable(False, True)
        self._scenarios: list[dict] = []
        self._creer_widgets()
        self._mettre_a_jour_mode()

    def _creer_widgets(self) -> None:
        pad = {"padx": 10, "pady": 5}

        # ── Titre ──────────────────────────────────────────────────────────────
        ttk.Label(
            self,
            text="Simulateur de Collision 100 % Inélastique à 90°",
            font=("Helvetica", 13, "bold"),
        ).grid(row=0, column=0, columnspan=2, **pad)

        # ── Sélection du mode ──────────────────────────────────────────────────
        cadre_mode = ttk.LabelFrame(self, text="Mode de calcul")
        cadre_mode.grid(row=1, column=0, columnspan=2, sticky="ew", **pad)
        self.var_mode = tk.StringVar(value="simulation")
        for col, (valeur, texte) in enumerate(self.MODES.items()):
            ttk.Radiobutton(
                cadre_mode,
                text=texte,
                variable=self.var_mode,
                value=valeur,
                command=self._mettre_a_jour_mode,
            ).grid(row=0, column=col, padx=12, pady=4)

        # ── Cadres de saisie des véhicules ─────────────────────────────────────
        self.cadre_a = CadreVehicule(self, "Véhicule A  (axe X →)")
        self.cadre_a.grid(row=2, column=0, sticky="nsew", **pad)

        self.cadre_b = CadreVehicule(self, "Véhicule B  (axe Y ↑)")
        self.cadre_b.grid(row=2, column=1, sticky="nsew", **pad)

        # ── Résultat connu (modes inverses) ────────────────────────────────────
        self.cadre_resultat_entree = ttk.LabelFrame(self, text="Résultat connu de la collision")
        self.cadre_resultat_entree.grid(row=3, column=0, columnspan=2, sticky="ew", **pad)

        ttk.Label(self.cadre_resultat_entree, text="Vitesse résultante v_f (km/h) :").grid(
            row=0, column=0, sticky="w", padx=8, pady=4
        )
        self.entry_vf = ttk.Entry(self.cadre_resultat_entree, width=10)
        self.entry_vf.grid(row=0, column=1, sticky="w", padx=5, pady=4)

        ttk.Label(self.cadre_resultat_entree, text="Angle θ (°) :").grid(
            row=0, column=2, sticky="w", padx=8, pady=4
        )
        self.entry_angle = ttk.Entry(self.cadre_resultat_entree, width=10)
        self.entry_angle.grid(row=0, column=3, sticky="w", padx=5, pady=4)

        # ── Bouton Calculer ────────────────────────────────────────────────────
        ttk.Button(self, text="  Calculer  ", command=self._calculer).grid(
            row=4, column=0, columnspan=2, pady=8
        )

        # ── Affichage du résultat ──────────────────────────────────────────────
        self.label_resultat = ttk.Label(
            self, text="Résultat : —", font=("Helvetica", 11, "bold")
        )
        self.label_resultat.grid(row=5, column=0, columnspan=2, **pad)

        # ── Bouton bas de page ─────────────────────────────────────────────────
        ttk.Button(
            self, text="Charger scénario…", command=self._charger_scenario
        ).grid(row=6, column=0, columnspan=2, pady=8)

    # ── Mise à jour de l'interface selon le mode ───────────────────────────────

    def _mettre_a_jour_mode(self) -> None:
        mode = self.var_mode.get()
        if mode == "simulation":
            self.cadre_a.set_vitesse_activee(True)
            self.cadre_b.set_vitesse_activee(True)
            self.cadre_resultat_entree.grid_remove()
        elif mode == "trouver_vb":
            self.cadre_a.set_vitesse_activee(True)
            self.cadre_b.set_vitesse_activee(False)
            self.cadre_resultat_entree.grid()
        elif mode == "trouver_va":
            self.cadre_a.set_vitesse_activee(False)
            self.cadre_b.set_vitesse_activee(True)
            self.cadre_resultat_entree.grid()

    # ── Calculs ────────────────────────────────────────────────────────────────

    def _calculer(self) -> None:
        mode = self.var_mode.get()
        try:
            if mode == "simulation":
                self._calculer_simulation()
            elif mode == "trouver_vb":
                self._calculer_trouver_vb()
            elif mode == "trouver_va":
                self._calculer_trouver_va()
        except ValueError as e:
            messagebox.showerror("Erreur de saisie", str(e))
        except Exception as e:
            messagebox.showerror("Erreur inattendue", str(e))

    def _calculer_simulation(self) -> None:
        va = self.cadre_a.get_vehicule()
        vb = self.cadre_b.get_vehicule()
        vf, angle = Collision.simuler(va, vb)
        resultat = f"v_f = {vf:.2f} km/h  |  θ = {angle:.2f}°"
        self._afficher_resultat(resultat)

    def _calculer_trouver_vb(self) -> None:
        va = self.cadre_a.get_vehicule()
        masse_eff_b = self.cadre_b.get_masse_effective()
        vf = float(self.entry_vf.get())
        angle = float(self.entry_angle.get())
        vitesse_b = Collision.trouver_vitesse_b(va, masse_eff_b, vf, angle)
        resultat = f"v_B = {vitesse_b:.2f} km/h"
        self._afficher_resultat(resultat)

    def _calculer_trouver_va(self) -> None:
        masse_eff_a = self.cadre_a.get_masse_effective()
        vb = self.cadre_b.get_vehicule()
        vf = float(self.entry_vf.get())
        angle = float(self.entry_angle.get())
        vitesse_a = Collision.trouver_vitesse_a(masse_eff_a, vb, vf, angle)
        resultat = f"v_A = {vitesse_a:.2f} km/h"
        self._afficher_resultat(resultat)

    # ── Affichage ──────────────────────────────────────────────────────────────

    def _afficher_resultat(self, texte: str) -> None:
        self.label_resultat.config(text=f"Résultat : {texte}")

    # ── Chargement de scénarios ────────────────────────────────────────────────

    def _charger_scenario(self) -> None:
        chemin = filedialog.askopenfilename(
            title="Choisir un fichier de scénarios",
            filetypes=[("Fichiers JSON", "*.json"), ("Tous les fichiers", "*.*")],
        )
        if not chemin:
            return
        try:
            scenarios = charger_scenarios(chemin)
        except (FileNotFoundError, ValueError) as e:
            messagebox.showerror("Erreur de chargement", str(e))
            return

        if not scenarios:
            messagebox.showinfo("Info", "Aucun scénario trouvé dans ce fichier.")
            return

        self._scenarios = scenarios
        self._afficher_selection_scenario()

    def _afficher_selection_scenario(self) -> None:
        fenetre = tk.Toplevel(self)
        fenetre.title("Choisir un scénario")
        fenetre.grab_set()

        ttk.Label(fenetre, text="Sélectionner un scénario :").pack(padx=10, pady=6)

        noms = [s.get("nom", f"Scénario {i + 1}") for i, s in enumerate(self._scenarios)]
        listbox = tk.Listbox(fenetre, width=52, height=min(len(noms), 8))
        for nom in noms:
            listbox.insert(tk.END, nom)
        listbox.pack(padx=10, pady=4)
        listbox.selection_set(0)

        def charger():
            selection = listbox.curselection()
            if not selection:
                return
            self._appliquer_scenario(self._scenarios[selection[0]])
            fenetre.destroy()

        ttk.Button(fenetre, text="Charger", command=charger).pack(pady=6)

    def _appliquer_scenario(self, scenario: dict) -> None:
        """Remplit les champs avec les données d'un scénario."""
        self._afficher_resultat("—")
        mode = scenario.get("mode", "simulation")
        self.var_mode.set(mode)
        self._mettre_a_jour_mode()

        if "vehicule_a" in scenario:
            self.cadre_a.remplir(scenario["vehicule_a"])

        if "vehicule_b" in scenario:
            self.cadre_b.remplir(scenario["vehicule_b"])

        # Modes inverses : remplir le résultat connu
        if mode in ("trouver_vb", "trouver_va"):
            self.entry_vf.delete(0, tk.END)
            self.entry_vf.insert(0, str(scenario.get("vitesse_resultante", "")))
            self.entry_angle.delete(0, tk.END)
            self.entry_angle.insert(0, str(scenario.get("angle", "")))

        # trouver_vb : le véhicule B n'a qu'une masse
        if mode == "trouver_vb" and "masse_b" in scenario:
            self.cadre_b.remplir(
                {"type": "voiture", "nom": "Véhicule B",
                 "masse": scenario["masse_b"], "vitesse": 0, "nb_passagers": 1}
            )
            self.cadre_b.set_vitesse_activee(False)

        # trouver_va : le véhicule A n'a qu'une masse
        if mode == "trouver_va" and "masse_a" in scenario:
            self.cadre_a.remplir(
                {"type": "voiture", "nom": "Véhicule A",
                 "masse": scenario["masse_a"], "vitesse": 0, "nb_passagers": 1}
            )
            self.cadre_a.set_vitesse_activee(False)
