class Vehicule:
    pass
