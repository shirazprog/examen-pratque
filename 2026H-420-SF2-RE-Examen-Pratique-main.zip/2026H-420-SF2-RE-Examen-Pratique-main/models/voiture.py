class Voiture:
    pass
