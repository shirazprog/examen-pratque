class Collision:
    pass
