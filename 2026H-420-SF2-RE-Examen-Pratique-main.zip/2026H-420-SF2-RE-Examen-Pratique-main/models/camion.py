class Camion:
    pass
