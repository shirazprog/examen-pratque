class HistoriqueCollisions:
    pass
