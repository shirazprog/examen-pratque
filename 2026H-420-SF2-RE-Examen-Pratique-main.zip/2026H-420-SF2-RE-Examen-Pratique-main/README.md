# Examen pratique 420-SF2-RE hiver 2026

Les consignes sont disponibles dans le document [2026H-420-SF2-RE-Examen-Pratique.pdf](./TeX/2026H-420-SF2-RE-Examen-Pratique.pdf).