import pytest
from models.vehicule import Vehicule


# Vehicule est abstraite : on utilise une sous-classe minimale pour tester
# les comportements définis dans la classe de base.
class VehiculeTest(Vehicule):
    def masse_effective(self) -> float:
        return self.masse


def test_creation_valide():
    v = VehiculeTest("Toyota", 1200.0, 60.0)
    assert v.nom == "Toyota"
    assert v.masse == 1200.0
    assert v.vitesse == 60.0


def test_masse_effective_egale_masse():
    v = VehiculeTest("Toyota", 1200.0, 60.0)
    assert v.masse_effective() == 1200.0


def test_vehicule_ne_peut_pas_etre_instancie_directement():
    with pytest.raises(TypeError, match="abstract"):
        Vehicule("Toyota", 1200.0, 60.0)  # type: ignore


def test_masse_invalide():
    with pytest.raises(ValueError):
        VehiculeTest("Toyota", -100.0, 60.0)


def test_masse_zero():
    with pytest.raises(ValueError):
        VehiculeTest("Toyota", 0.0, 60.0)


def test_vitesse_negative():
    with pytest.raises(ValueError):
        VehiculeTest("Toyota", 1200.0, -10.0)


def test_vitesse_zero_valide():
    v = VehiculeTest("Toyota", 1200.0, 0.0)
    assert v.vitesse == 0.0


def test_str_contient_nom_et_masse():
    v = VehiculeTest("Toyota", 1200.0, 60.0)
    s = str(v)
    assert "Toyota" in s
    assert "1200" in s
