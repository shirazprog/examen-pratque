import json
import pytest
from models.voiture import Voiture
from models.camion import Camion
from utils.fichiers import charger_scenarios, creer_vehicule


# ── charger_scenarios ──────────────────────────────────────────────────────────

def test_charger_scenarios_valide(tmp_path):
    donnees = [
        {
            "nom": "Test",
            "mode": "simulation",
            "vehicule_a": {"type": "voiture", "nom": "A", "masse": 1000.0, "vitesse": 50.0},
            "vehicule_b": {"type": "voiture", "nom": "B", "masse": 800.0, "vitesse": 40.0},
        }
    ]
    fichier = tmp_path / "scenarios.json"
    fichier.write_text(json.dumps(donnees), encoding="utf-8")

    result = charger_scenarios(str(fichier))
    assert len(result) == 1
    assert result[0]["nom"] == "Test"


def test_charger_scenarios_retourne_liste(tmp_path):
    fichier = tmp_path / "vide.json"
    fichier.write_text("[]", encoding="utf-8")
    result = charger_scenarios(str(fichier))
    assert isinstance(result, list)
    assert len(result) == 0


def test_charger_scenarios_fichier_inexistant():
    with pytest.raises(FileNotFoundError):
        charger_scenarios("fichier_qui_nexiste_pas.json")


def test_charger_scenarios_json_invalide(tmp_path):
    fichier = tmp_path / "mauvais.json"
    fichier.write_text("{ceci n'est pas du JSON", encoding="utf-8")
    with pytest.raises(ValueError):
        charger_scenarios(str(fichier))


def test_charger_scenarios_pas_une_liste(tmp_path):
    fichier = tmp_path / "dict.json"
    fichier.write_text('{"nom": "pas une liste"}', encoding="utf-8")
    with pytest.raises(ValueError):
        charger_scenarios(str(fichier))


# ── creer_vehicule ─────────────────────────────────────────────────────────────

def test_creer_vehicule_voiture():
    data = {"type": "voiture", "nom": "Civic", "masse": 1100.0, "vitesse": 50.0, "nb_passagers": 2}
    v = creer_vehicule(data)
    assert isinstance(v, Voiture)
    assert v.nom == "Civic"
    assert v.nb_passagers == 2


def test_creer_vehicule_camion():
    data = {"type": "camion", "nom": "Kenworth", "masse": 8000.0, "vitesse": 80.0, "charge_utile": 5000.0}
    c = creer_vehicule(data)
    assert isinstance(c, Camion)
    assert c.masse_effective() == 13000.0


def test_creer_vehicule_voiture_sans_passagers():
    data = {"type": "voiture", "nom": "Focus", "masse": 1200.0, "vitesse": 60.0}
    v = creer_vehicule(data)
    assert isinstance(v, Voiture)
    assert v.nb_passagers == 1  # valeur par défaut


def test_creer_vehicule_camion_sans_charge():
    data = {"type": "camion", "nom": "Mack", "masse": 6000.0, "vitesse": 70.0}
    c = creer_vehicule(data)
    assert isinstance(c, Camion)
    assert c.masse_effective() == 6000.0


def test_creer_vehicule_type_inconnu():
    data = {"type": "moto", "nom": "Harley", "masse": 300.0, "vitesse": 100.0}
    with pytest.raises(ValueError):
        creer_vehicule(data)
