import pytest
from models.historique import HistoriqueCollisions
from models.voiture import Voiture


def _voiture(nom="Civic"):
    return Voiture(nom, 1200.0, 50.0)


class TestHistoriqueCollisions:
    def test_vide_au_depart(self):
        h = HistoriqueCollisions()
        assert h.est_vide()
        assert len(h) == 0

    def test_ajouter_un_resultat(self):
        h = HistoriqueCollisions()
        h.ajouter(_voiture("A"), _voiture("B"), 45.0, 35.0)
        assert not h.est_vide()
        assert len(h) == 1

    def test_ajouter_plusieurs_resultats(self):
        h = HistoriqueCollisions()
        h.ajouter(_voiture(), _voiture(), 10.0, 10.0)
        h.ajouter(_voiture(), _voiture(), 20.0, 20.0)
        assert len(h) == 2

    def test_dernier_retourne_bon_resultat(self):
        h = HistoriqueCollisions()
        h.ajouter(_voiture("A"), _voiture("B"), 45.0, 35.0)
        r = h.dernier()
        assert r["vitesse_resultante"] == 45.0
        assert r["angle"] == 35.0

    def test_dernier_ne_retire_pas(self):
        h = HistoriqueCollisions()
        h.ajouter(_voiture(), _voiture(), 40.0, 30.0)
        h.dernier()
        assert len(h) == 1

    def test_dernier_vide_leve_index_error(self):
        h = HistoriqueCollisions()
        with pytest.raises(IndexError):
            h.dernier()

    def test_retirer_dernier_retourne_sommet(self):
        h = HistoriqueCollisions()
        h.ajouter(_voiture(), _voiture(), 10.0, 10.0)
        h.ajouter(_voiture(), _voiture(), 55.0, 45.0)
        r = h.retirer_dernier()
        assert r["vitesse_resultante"] == 55.0

    def test_retirer_dernier_reduit_taille(self):
        h = HistoriqueCollisions()
        h.ajouter(_voiture(), _voiture(), 40.0, 30.0)
        h.ajouter(_voiture(), _voiture(), 55.0, 45.0)
        h.retirer_dernier()
        assert len(h) == 1

    def test_retirer_dernier_vide_leve_index_error(self):
        h = HistoriqueCollisions()
        with pytest.raises(IndexError):
            h.retirer_dernier()

    def test_ordre_lifo(self):
        h = HistoriqueCollisions()
        h.ajouter(_voiture(), _voiture(), 10.0, 10.0)
        h.ajouter(_voiture(), _voiture(), 20.0, 20.0)
        assert h.retirer_dernier()["vitesse_resultante"] == 20.0
        assert h.retirer_dernier()["vitesse_resultante"] == 10.0

    def test_tout_retourne_tous_les_resultats(self):
        h = HistoriqueCollisions()
        h.ajouter(_voiture(), _voiture(), 10.0, 10.0)
        h.ajouter(_voiture(), _voiture(), 20.0, 20.0)
        assert len(h.tout()) == 2

    def test_tout_retourne_copie(self):
        h = HistoriqueCollisions()
        h.ajouter(_voiture(), _voiture(), 10.0, 10.0)
        h.tout().clear()
        assert len(h) == 1

    def test_tout_ordre_du_plus_ancien_au_plus_recent(self):
        h = HistoriqueCollisions()
        h.ajouter(_voiture(), _voiture(), 10.0, 10.0)
        h.ajouter(_voiture(), _voiture(), 20.0, 20.0)
        resultats = h.tout()
        assert resultats[0]["vitesse_resultante"] == 10.0
        assert resultats[1]["vitesse_resultante"] == 20.0

    def test_vider(self):
        h = HistoriqueCollisions()
        h.ajouter(_voiture(), _voiture(), 40.0, 30.0)
        h.vider()
        assert h.est_vide()
        assert len(h) == 0

    def test_vehicules_stockes_comme_str(self):
        h = HistoriqueCollisions()
        h.ajouter(_voiture("Civic"), _voiture("Corolla"), 45.0, 35.0)
        r = h.dernier()
        assert isinstance(r["vehicule_a"], str)
        assert isinstance(r["vehicule_b"], str)
