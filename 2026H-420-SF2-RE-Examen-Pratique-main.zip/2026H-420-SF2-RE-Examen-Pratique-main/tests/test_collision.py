"""
Tests pour la classe Collision.

Formules utilisées (collision 100 % inélastique à 90°) :
    v_fx = m_A * v_A / (m_A + m_B)
    v_fy = m_B * v_B / (m_A + m_B)
    v_f  = sqrt(v_fx² + v_fy²)
    θ    = atan2(v_fy, v_fx)  [degrés]

    v_A  = v_f * cos(θ) * (m_A + m_B) / m_A
    v_B  = v_f * sin(θ) * (m_A + m_B) / m_B
"""
import math
import pytest
from models.voiture import Voiture
from models.camion import Camion
from models.collision import Collision


# ── simuler ────────────────────────────────────────────────────────────────────

def test_simuler_deux_voitures():
    # masse_effective : A=1200+1*80=1280, B=1000+1*80=1080, m_tot=2360
    # v_fx = 1280*50/2360 = 27.12  v_fy = 1080*40/2360 = 18.31
    # v_f  ≈ 32.72  θ = atan2(18.31, 27.12) ≈ 34.02°
    a = Voiture("A", 1200.0, 50.0)
    b = Voiture("B", 1000.0, 40.0)
    vf, angle = Collision.simuler(a, b)
    assert vf == pytest.approx(32.72, abs=0.1)
    assert angle == pytest.approx(34.02, abs=0.1)


def test_simuler_utilise_masse_effective_camion():
    # masse_effective : A=1200+1*80=1280, B=8000+5000=13000, m_tot=14280
    # v_fx = 1280*50/14280 = 4.48  v_fy = 13000*20/14280 = 18.21
    # v_f  ≈ 18.75  θ = atan2(18.21, 4.48) ≈ 76.17°
    a = Voiture("A", 1200.0, 50.0)
    b = Camion("B", 8000.0, 20.0, 5000.0)
    vf, angle = Collision.simuler(a, b)
    assert vf == pytest.approx(18.75, abs=0.1)
    assert angle == pytest.approx(76.17, abs=0.1)


def test_simuler_vehicule_arrete():
    # Si B est arrêté, la résultante est entièrement selon l'axe X (θ = 0°)
    a = Voiture("A", 1000.0, 60.0)
    b = Voiture("B", 1000.0, 0.0)
    vf, angle = Collision.simuler(a, b)
    assert vf == pytest.approx(30.0, abs=0.01)
    assert angle == pytest.approx(0.0, abs=0.01)


# ── trouver_vitesse_b ──────────────────────────────────────────────────────────

def test_trouver_vitesse_b_coherent_avec_simulation():
    # Simulation de référence : m_A=1400, v_A=70, m_B=1200, v_B=45 → v_f, θ
    a = Voiture("A", 1400.0, 70.0)
    b = Voiture("B", 1200.0, 45.0)
    vf, angle = Collision.simuler(a, b)

    # Retrouver v_B à partir de v_f et θ (utiliser masse_effective de b)
    vitesse_b = Collision.trouver_vitesse_b(a, b.masse_effective(), vf, angle)
    assert vitesse_b == pytest.approx(45.0, abs=0.01)


def test_trouver_vitesse_b_masse_invalide():
    a = Voiture("A", 1400.0, 70.0)
    with pytest.raises(ValueError):
        Collision.trouver_vitesse_b(a, 0.0, 43.0, 28.0)


def test_trouver_vitesse_b_utilise_masse_effective():
    # Le camion A a masse_effective = 2000 + 3000 = 5000
    a = Camion("A", 2000.0, 40.0, 3000.0)
    b = Voiture("B", 1500.0, 30.0)
    vf, angle = Collision.simuler(a, b)

    vitesse_b = Collision.trouver_vitesse_b(a, b.masse_effective(), vf, angle)
    assert vitesse_b == pytest.approx(30.0, abs=0.01)


# ── trouver_vitesse_a ──────────────────────────────────────────────────────────

def test_trouver_vitesse_a_coherent_avec_simulation():
    # Simulation de référence : m_A=1400, v_A=70, m_B=1200, v_B=45 → v_f, θ
    a = Voiture("A", 1400.0, 70.0)
    b = Voiture("B", 1200.0, 45.0)
    vf, angle = Collision.simuler(a, b)

    # Retrouver v_A à partir de v_f et θ (utiliser masse_effective de a)
    vitesse_a = Collision.trouver_vitesse_a(a.masse_effective(), b, vf, angle)
    assert vitesse_a == pytest.approx(70.0, abs=0.01)


def test_trouver_vitesse_a_masse_invalide():
    b = Voiture("B", 1200.0, 45.0)
    with pytest.raises(ValueError):
        Collision.trouver_vitesse_a(-500.0, b, 43.0, 28.0)


def test_trouver_vitesse_a_utilise_masse_effective():
    # Le camion B a masse_effective = 3000 + 2000 = 5000
    a = Voiture("A", 1500.0, 60.0)
    b = Camion("B", 3000.0, 25.0, 2000.0)
    vf, angle = Collision.simuler(a, b)

    vitesse_a = Collision.trouver_vitesse_a(a.masse_effective(), b, vf, angle)
    assert vitesse_a == pytest.approx(60.0, abs=0.01)
