import pytest
from models.vehicule import Vehicule
from models.camion import Camion


def test_creation_valide():
    c = Camion("Kenworth", 8000.0, 80.0, 5000.0)
    assert c.nom == "Kenworth"
    assert c.masse == 8000.0
    assert c.vitesse == 80.0
    assert c.charge_utile == 5000.0


def test_est_instance_vehicule():
    c = Camion("Kenworth", 8000.0, 80.0)
    assert isinstance(c, Vehicule)


def test_charge_utile_par_defaut():
    c = Camion("Kenworth", 8000.0, 80.0)
    assert c.charge_utile == 0.0


def test_masse_effective_avec_charge():
    c = Camion("Kenworth", 8000.0, 80.0, 5000.0)
    assert c.masse_effective() == 13000.0


def test_masse_effective_sans_charge():
    c = Camion("Kenworth", 8000.0, 80.0)
    assert c.masse_effective() == 8000.0


def test_charge_utile_negative():
    with pytest.raises(ValueError):
        Camion("Kenworth", 8000.0, 80.0, -100.0)


def test_masse_invalide():
    with pytest.raises(ValueError):
        Camion("Kenworth", 0.0, 80.0)


def test_str_contient_nom_et_charge():
    c = Camion("Kenworth", 8000.0, 80.0, 5000.0)
    s = str(c)
    assert "Kenworth" in s
    assert "5000" in s
