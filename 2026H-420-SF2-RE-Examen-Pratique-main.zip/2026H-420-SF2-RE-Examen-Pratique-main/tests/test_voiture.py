import pytest
from models.vehicule import Vehicule
from models.voiture import Voiture


def test_creation_valide():
    v = Voiture("Civic", 1100.0, 50.0, 2)
    assert v.nom == "Civic"
    assert v.masse == 1100.0
    assert v.vitesse == 50.0
    assert v.nb_passagers == 2


def test_est_instance_vehicule():
    v = Voiture("Civic", 1100.0, 50.0)
    assert isinstance(v, Vehicule)


def test_nb_passagers_par_defaut():
    v = Voiture("Civic", 1100.0, 50.0)
    assert v.nb_passagers == 1


def test_masse_effective_inclut_passagers():
    # masse_effective = masse + nb_passagers * 80 kg
    v = Voiture("Civic", 1100.0, 50.0, 3)
    assert v.masse_effective() == 1100.0 + 3 * 80.0


def test_masse_effective_sans_passager():
    v = Voiture("Civic", 1100.0, 50.0, 0)
    assert v.masse_effective() == 1100.0


def test_nb_passagers_invalide():
    with pytest.raises(ValueError):
        Voiture("Civic", 1100.0, 50.0, -1)


def test_masse_invalide():
    with pytest.raises(ValueError):
        Voiture("Civic", 0.0, 50.0)


def test_vitesse_negative():
    with pytest.raises(ValueError):
        Voiture("Civic", 1100.0, -5.0)


def test_str_contient_nom_et_passagers():
    v = Voiture("Civic", 1100.0, 50.0, 2)
    s = str(v)
    assert "Civic" in s
    assert "2" in s
